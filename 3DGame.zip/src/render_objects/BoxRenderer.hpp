#pragma once

#include "../graphics/graphics.hpp"

class BoxRenderer
{
private:
    VertexArray m_Vao;

    Shader* m_Shader;
    Texture* m_Texture;

    glm::mat4 m_ModelMatrix;

public:
    BoxRenderer();
    BoxRenderer(const glm::vec3& position, const glm::vec3& size, Shader* shader, Texture* texture, float texScale, float dimm);
    ~BoxRenderer();


    void Render();

    void SetPosition(const glm::vec3& position);

    void Rotate();

};
