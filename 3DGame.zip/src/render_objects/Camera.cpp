#include "Camera.hpp"
#include <iostream>

Camera::Camera()
{

}

Camera::Camera(int p_frameBufferWidth, int p_frameBufferHeight)
    :m_Position(glm::vec3(0.0f)), m_AngleX(0), m_AngleY(0)
{
    m_OrthoView = glm::translate(glm::mat4(1.0f),glm::vec3(0.0f));
    m_OrthoProjection = glm::ortho(0.0f, (float)SCREEN_WIDTH, 0.0f, (float)SCREEN_HEIGHT, -1.0f, 1.0f);

    m_Front.x = cos(glm::radians(m_AngleX-90));
    m_Front.z = sin(glm::radians(m_AngleX-90));
    m_Front.y = cos(glm::radians(m_AngleY+90));

    m_PerspectiveView = glm::lookAt(m_Position,m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));

    m_PerspectiveProjection = glm::perspective(glm::radians(50.0f), (float)p_frameBufferWidth/p_frameBufferHeight, 0.001f,100.0f);

}

void Camera::Reset()
{
    m_AngleX = 0;
    m_AngleY = 0;

    m_Front.x = cos(glm::radians(m_AngleX-90));
    m_Front.z = sin(glm::radians(m_AngleX-90));
    m_Front.y = cos(glm::radians(m_AngleY+90));

    m_PerspectiveView = glm::lookAt(m_Position,m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}

void Camera::SetPosition(const glm::vec3 &position)
{
    m_Position = position;

    m_PerspectiveView = glm::lookAt(m_Position, m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));

}

void Camera::Turn(float x, float y)
{
    m_AngleX += x;

    if(m_AngleY > 1.5f && y > 0)
        y = 0;
    else if(m_AngleY < -1.5f && y < 0)
        y = 0;

    m_AngleY += y * 0.02 * 1;

    m_Front.x = cos(glm::radians(m_AngleX-90));
    m_Front.z = sin(glm::radians(m_AngleX-90));
    m_Front.y = tanh(m_AngleY);

    m_PerspectiveView = glm::lookAt(m_Position ,m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}

void Camera::SetObstacles(bool frontObstacle, bool backObstacle, bool leftObstacle, bool rightObstacle)
{
    m_RestraintFront  = false;
    m_RestraintBack  = false;
    m_RestraintLeft  = false;
    m_RestraintRight = false;

    m_RestraintFront = frontObstacle;
    m_RestraintBack = backObstacle;
    m_RestraintLeft = leftObstacle;
    m_RestraintRight = rightObstacle;


}

void Camera::Move(Direction dir, float speed)
{
    switch(dir)
    {
        case NONE:
            break;

        case UP:
            MoveForward(speed);
            break;

        case DOWN:
            MoveBack(speed);
            break;

        case LEFT:
            MoveLeft(speed);
            break;
        case RIGHT:
            MoveRight(speed);
            break;
    }
}

//PRIVATE

void Camera::MoveForward(float speed)
{
    float x = sin(glm::radians(m_AngleX)) * speed;
    float z = cos(glm::radians(m_AngleX)) * speed;

    z = -z;


    x = m_RestraintLeft && x < 0 ? 0 : x;
    x = m_RestraintRight && x > 0 ? 0 : x;

    z = m_RestraintFront && z < 0 ? 0 : z;
    z = m_RestraintBack && z > 0 ? 0 : z;


    m_Position += glm::vec3(x, 0.0f, z);

    m_PerspectiveView = glm::lookAt(m_Position , m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}

void Camera::MoveBack(float speed)
{
    float x = sin(glm::radians(m_AngleX)) * speed;
    float z = cos(glm::radians(m_AngleX)) * speed;

    x = -x;

    x = m_RestraintLeft && x < 0 ? 0 : x;
    x = m_RestraintRight && x > 0 ? 0 : x;

    z = m_RestraintFront && z < 0 ? 0 : z;
    z = m_RestraintBack && z > 0 ? 0 : z;


    m_Position += glm::vec3(x, 0.0f, z);

    m_PerspectiveView = glm::lookAt(m_Position , m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}

void Camera::MoveLeft(float speed)
{

    float x = sin(glm::radians(m_AngleX)) * speed;
    float z = cos(glm::radians(m_AngleX)) * speed;

    x = -x;
    z = -z;

    z = m_RestraintLeft && z < 0 ? 0 : z;
    z = m_RestraintRight && z > 0 ? 0 : z;

    x = m_RestraintFront && x < 0 ? 0 : x;
    x = m_RestraintBack && x > 0 ? 0 : x;

    m_Position += glm::vec3(z, 0.0f, x);

    m_PerspectiveView = glm::lookAt(m_Position , m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}

void Camera::MoveRight(float speed)
{
    float x = sin(glm::radians(m_AngleX)) * speed;
    float z = cos(glm::radians(m_AngleX)) * speed;

    z = m_RestraintLeft && z < 0 ? 0 : z;
    z = m_RestraintRight && z > 0 ? 0 : z;

    x = m_RestraintFront && x < 0 ? 0 : x;
    x = m_RestraintBack && x > 0 ? 0 : x;


    m_Position += glm::vec3(z, 0.0f, x);

    m_PerspectiveView = glm::lookAt(m_Position , m_Position + m_Front, glm::vec3(0.0f,1.0f,0.0f));
}
