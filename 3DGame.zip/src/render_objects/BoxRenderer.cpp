#include "BoxRenderer.hpp"

BoxRenderer::BoxRenderer()
{

}

BoxRenderer::BoxRenderer(const glm::vec3& position, const glm::vec3& size, Shader* shader, Texture* texture, float texScale,float dimm)
{
    m_Shader = shader;
    m_Texture = texture;


    float upX = size.x * texScale;
    float upY = size.z * texScale;

    float leftX = size.z * texScale;
    float leftY = size.y * texScale;

    float frontX = size.x * texScale;
    float frontY = size.y * texScale;


    float verticies[] =
    {
        //FRONT
        -size.x, -size.y, size.z,   dimm,dimm,dimm,     0.0f,       0.0f,        0.0f, 0.0f, 1.0f,
         size.x, -size.y, size.z,   dimm,dimm,dimm,     frontX,   0.0f,          0.0f, 0.0f, 1.0f,
         size.x,  size.y, size.z,   dimm,dimm,dimm,     frontX,   frontY,        0.0f, 0.0f, 1.0f,
        -size.x,  size.y, size.z,   dimm,dimm,dimm,     0.0f,     frontY,        0.0f, 0.0f, 1.0f,

        //BACK
         size.x, -size.y, -size.z,  dimm,dimm,dimm,     0.0f,       0.0f,        0.0f, 0.0f, -1.0f,
        -size.x, -size.y, -size.z,  dimm,dimm,dimm,     frontX,   0.0f,          0.0f, 0.0f, -1.0f,
        -size.x,  size.y, -size.z,  dimm,dimm,dimm,     frontX,   frontY,        0.0f, 0.0f, -1.0f,
         size.x,  size.y, -size.z,  dimm,dimm,dimm,     0.0f,     frontY,        0.0f, 0.0f, -1.0f,

         //LEFT
        -size.x, -size.y, -size.z,  dimm,dimm,dimm,     0.0f,  0.0f,            -1.0f, 0.0f, 0.0f,
        -size.x, -size.y,  size.z,  dimm,dimm,dimm,     leftX, 0.0f,            -1.0f, 0.0f, 0.0f,
        -size.x,  size.y,  size.z,  dimm,dimm,dimm,     leftX, leftY,           -1.0f, 0.0f, 0.0f,
        -size.x,  size.y, -size.z,  dimm,dimm,dimm,     0.0f,  leftY,           -1.0f, 0.0f, 0.0f,

         //RIGHT
         size.x, -size.y,  size.z,  dimm,dimm,dimm,     0.0f, 0.0f,              1.0f, 0.0f, 0.0f,
         size.x, -size.y, -size.z,  dimm,dimm,dimm,     leftX, 0.0f,             1.0f, 0.0f, 0.0f,
         size.x,  size.y, -size.z,  dimm,dimm,dimm,     leftX, leftY,            1.0f, 0.0f, 0.0f,
         size.x,  size.y,  size.z,  dimm,dimm,dimm,     0.0f, leftY,             1.0f, 0.0f, 0.0f,

         //UP
        -size.x,  size.y,  size.z,  dimm,dimm,dimm,     0.0f, 0.0f,              0.0f, 1.0f, 0.0f,
         size.x,  size.y,  size.z,  dimm,dimm,dimm,     upX, 0.0f,               0.0f, 1.0f, 0.0f,
         size.x,  size.y, -size.z,  dimm,dimm,dimm,     upX, upY,                0.0f, 1.0f, 0.0f,
        -size.x,  size.y, -size.z,  dimm,dimm,dimm,     0.0f, upY,               0.0f, 1.0f, 0.0f,

         //DOWN
         size.x, -size.y,  size.z,  dimm,dimm,dimm,     0.0f, 0.0f,              0.0f, -1.0f, 0.0f,
        -size.x, -size.y,  size.z,  dimm,dimm,dimm,     upX, 0.0f,               0.0f, -1.0f, 0.0f,
        -size.x, -size.y, -size.z,  dimm,dimm,dimm,     upX, upY,                0.0f, -1.0f, 0.0f,
         size.x, -size.y, -size.z,  dimm,dimm,dimm,     0.0f, upY,               0.0f, -1.0f, 0.0f

    };

    unsigned int indicies[]=
    {
        0, 1, 2,
        0, 2, 3,

        4, 5, 6,
        4, 6, 7,

        8, 9, 10,
        8, 10, 11,

        12, 13, 14,
        12, 14, 15,

        16, 17, 18,
        16, 18, 19,

        20, 21, 22,
        20, 22, 23

    };


    m_Vao.Bind();

    VertexBuffer vb((4 * 11) * 6 * sizeof(float),verticies);

    VertexBufferLayout layout;

    layout.PushBytes<float>(3);
    layout.PushBytes<float>(3);
    layout.PushBytes<float>(2);
    layout.PushBytes<float>(3);

    m_Vao.AddBuffer(vb,layout);


    IndexBuffer ib(6 * 6, indicies);

    m_ModelMatrix = glm::translate(glm::mat4(1.0f), position);

    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix",m_ModelMatrix);

    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());


}

BoxRenderer::~BoxRenderer()
{

}


void BoxRenderer::Render()
{
    m_Vao.Bind();
    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix",m_ModelMatrix);
    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());
    glDrawElements(GL_TRIANGLES, 6 * 6, GL_UNSIGNED_INT, 0);
}

void BoxRenderer::SetPosition(const glm::vec3 &position)
{
    m_ModelMatrix = glm::translate(glm::mat4(1.0f), position);
}


void BoxRenderer::Rotate()
{
    m_ModelMatrix = glm::rotate(m_ModelMatrix, glm::radians(1.5f), glm::vec3(0.0f, 1.0f, 0.0f));
}
