#include "Model3D.hpp"

Model3D::Model3D()
{

}

Model3D::Model3D(const std::string& filepath, const glm::vec3& position, float scale, Shader* shader, Texture* texture)
{
    m_Shader = shader;
    m_Texture = texture;

    std::ifstream inFile(filepath.c_str());

    if(!inFile.is_open())
        std::cout << "3DModel can't find filepath!\n";

    std::vector<float> positions;
    std::vector<float> texCoords;
    std::vector<float> normals;

    std::string word;
    while(inFile >> word)
    {
        if(word == "v")
        {
            float pos;
            inFile >> pos;
            positions.push_back(pos);
            inFile >> pos;
            positions.push_back(pos);
            inFile >> pos;
            positions.push_back(pos);
        }

        else if(word == "vt")
        {
            float tex;
            inFile >> tex;
            texCoords.push_back(tex);
            inFile >> tex;
            texCoords.push_back(tex);
            inFile >> tex;
            texCoords.push_back(tex);
        }

        else if(word == "vn")
        {
            float norm;
            inFile >> norm;
            normals.push_back(norm);
            inFile >> norm;
            normals.push_back(norm);
            inFile >> norm;
            normals.push_back(norm);
        }
    }

    inFile.close();


    std::vector<int> layout;

    inFile.open(filepath.c_str());

    std::vector<unsigned int> indicies;

    std::string number;
    while(inFile >> word)
    {
        if(word == "f")
        {
            for(int p = 0; p < 3; p++)
            {
                inFile >> word;
                char ch;
                std::string number("");
                for(unsigned int i = 0; i < word.size(); i++)
                {
                    while(word[i] != '/')
                    {
                        ch = word[i];
                        number += ch;
                        i++;
                    }
                    int num = std::stoi(number);
                    layout.push_back(std::stoi(number));
                    indicies.push_back(num-1);

                    while(word[i] != '/')
                    {
                        ch = word[i];
                        number += ch;
                        i++;
                    }

                    layout.push_back(std::stoi(number));


                    while(i < word.size())
                    {
                        ch = word[i];
                        number += ch;
                        i++;
                    }

                    layout.push_back(std::stoi(number));

                }
            }
        }
    }

    inFile.close();




    std::vector<float> verticies;

    int norm = 0;
    int tex = 0;

    for(unsigned int i = 0; i < positions.size(); )
    {

        verticies.push_back(positions[i] * scale);
        verticies.push_back(positions[i+1]* scale);
        verticies.push_back(positions[i+2]* scale);

        i += 3;

        verticies.push_back(1.0f);
        verticies.push_back(1.0f);
        verticies.push_back(1.0f);


        verticies.push_back(texCoords[tex]);
        verticies.push_back(texCoords[tex+1]);


        tex += 3;

        verticies.push_back(normals[norm]);
        verticies.push_back(normals[norm+1]);
        verticies.push_back(normals[norm+2]);

        norm += 3;


    }


    m_Vao.Bind();

    VertexBuffer vb(verticies.size() * sizeof(float), &verticies[0]);

    VertexBufferLayout vbLayout;

    vbLayout.PushBytes<float>(3);
    vbLayout.PushBytes<float>(3);
    vbLayout.PushBytes<float>(2);
    vbLayout.PushBytes<float>(3);

    m_Vao.AddBuffer(vb, vbLayout);

    m_IndexCount = indicies.size();
    IndexBuffer ib(m_IndexCount, &indicies[0]);



    m_ModelMatrix = glm::translate(glm::mat4(1.0f),position);

    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix",m_ModelMatrix);

    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());

}

Model3D::~Model3D()
{

}

void Model3D::Render()
{
    m_Vao.Bind();
    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix", m_ModelMatrix);
    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());

    glDrawElements(GL_TRIANGLES, m_IndexCount, GL_UNSIGNED_INT, 0);
}


void Model3D::Rotate(char axis, float degrees)
{
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;

    switch(axis)
    {
        case 'x':
            x = 1.0f;
            break;

        case 'y':
            y = 1.0f;
            break;

        case 'z':
            z = 1.0f;
            break;

        default:
            break;
    }


    m_ModelMatrix = glm::rotate(m_ModelMatrix, glm::radians(degrees), glm::vec3(x,y,z));
}

void Model3D::SetPos(const glm::vec3 &pos)
{
    m_ModelMatrix = glm::translate(glm::mat4(1.0f), pos);
}
