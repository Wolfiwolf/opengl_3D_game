#pragma once

#include "../graphics/graphics.hpp"

class Image
{
private:
    VertexArray m_Vao;

    Shader* m_Shader;

    Texture* m_Texture;

    glm::mat4 m_ModelMatrix;

public:
    Image();
    Image(const std::string& filepath, float dimm, const glm::vec2& position, const glm::vec2& size, Shader* shader);


    void Render();
};
