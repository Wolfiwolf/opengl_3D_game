#include "Image.hpp"

Image::Image()
{

}

Image::Image(const std::string& filepath, float dimm, const glm::vec2& position,
            const glm::vec2& size, Shader* shader)
{
    m_Shader = shader;

    float verticies[] =
    {
        -size.x, -size.y,  dimm,dimm,dimm,     0.0f, 0.0f,
         size.x, -size.y,  dimm,dimm,dimm,     1.0f, 0.0f,
         size.x,  size.y,  dimm,dimm,dimm,     1.0f, 1.0f,
        -size.x,  size.y,  dimm,dimm,dimm,     0.0f, 1.0f
    };

    unsigned int indicies[]=
    {
        0, 1, 2,
        0, 2, 3
    };

    m_Vao.Bind();

    VertexBuffer vb(4 * 7 * sizeof(float),verticies);

    VertexBufferLayout layout;

    layout.PushBytes<float>(2);
    layout.PushBytes<float>(3);
    layout.PushBytes<float>(2);

    m_Vao.AddBuffer(vb,layout);

    IndexBuffer ib(6, indicies);

    m_ModelMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(position,0.0f));

    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix",m_ModelMatrix);
    m_Texture =  new Texture(filepath);
    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());

}


void Image::Render()
{
    m_Vao.Bind();
    m_Shader->Bind();
    m_Shader->SetUnifrom4Mat("u_model_matrix",m_ModelMatrix);
    m_Texture->Bind();
    m_Shader->SetUnifrom1i("u_texture", m_Texture->GetTextureIndex());
    glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
}
