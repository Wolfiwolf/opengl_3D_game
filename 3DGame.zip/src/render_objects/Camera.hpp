#pragma once
#include "../vendor/glm/gtc/quaternion.hpp"
#include "../Directions.hpp"


#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720


class Camera
{
private:
    glm::vec3 m_Position;

    float m_AngleX;
    float m_AngleY;

    glm::mat4 m_OrthoView;
    glm::mat4 m_OrthoProjection;

    glm::mat4 m_PerspectiveView;
    glm::mat4 m_PerspectiveProjection;

    glm::vec3 m_Front;

    //RESTRAINS

    bool m_RestraintFront;
    bool m_RestraintBack;
    bool m_RestraintLeft;
    bool m_RestraintRight;

public:
    Camera();
    Camera(int p_frameBufferWidth, int p_frameBufferHeight);

    void Reset();

    void Turn(float x, float y);

    void SetObstacles(bool frontObstacle, bool backObstacle, bool leftObstacle, bool rightObstacle);

    void Move(Direction dir, float speed);

    void SetPosition(const glm::vec3& p_position);

    // GET

    inline const  glm::vec3& GetPosition() const
    {
        return m_Position;
    }

    inline const glm::mat4& GetOrthoView() const
    {
        return m_OrthoView;
    }

    inline const glm::mat4& GetOrthoProjection() const
    {
        return m_OrthoProjection;
    }

    inline const glm::mat4& GetPerspectiveView() const
    {
        return m_PerspectiveView;
    }

    inline const glm::mat4& GetPerspectiveProjection() const
    {
        return m_PerspectiveProjection;
    }

private:
    void MoveForward(float speed);
    void MoveBack(float speed);
    void MoveLeft(float speed);
    void MoveRight(float speed);
};
