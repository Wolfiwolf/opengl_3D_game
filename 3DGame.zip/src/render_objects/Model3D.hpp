#pragma once

#include "../graphics/graphics.hpp"


class Model3D
{
private:
    VertexArray m_Vao;
    unsigned int m_IndexCount;

    Shader* m_Shader;
    Texture* m_Texture;

    glm::mat4 m_ModelMatrix;

public:
    Model3D();
    Model3D(const std::string& filePath, const glm::vec3& position, float scale, Shader* shader, Texture* texture);
    ~Model3D();

    void Render();

    void Rotate(char axis, float degrees);

    void SetPos(const glm::vec3& pos);

};
