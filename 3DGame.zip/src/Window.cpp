#include "Window.hpp"

unsigned int Window::s_EventCount = 0;
Event* Window::s_Events[10];

unsigned int Window::s_Width = 0;
unsigned int Window::s_Height = 0;

Window::Window(const std::string& title, unsigned int width, unsigned int height)
{
    s_Width = width;
    s_Height = height;
    if (!glfwInit())
        std::cout << "GLFW init failed!\n";


    m_Window = glfwCreateWindow(width, height, title.c_str(), NULL, NULL);
    if (!m_Window)
    {
        glfwTerminate();
        std::cout << "WINDOW failed!\n";
    }


    glfwMakeContextCurrent(m_Window);
    if(!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
        std::cout << "GLAD failed!\n";

    glfwSwapInterval(1);

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    glEnable (GL_DEPTH_TEST);

    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);

    glfwGetFramebufferSize(m_Window, &m_FrameBufferWidth, &m_FrameBufferHeight);
    glViewport(0.0f,0.0f, m_FrameBufferWidth, m_FrameBufferHeight);


    glfwSetWindowCloseCallback(m_Window, [](GLFWwindow* window)
    {
        Event* event = new WindowClosedEvent;
        s_Events[s_EventCount] = event;
        s_EventCount++;
    });

    glfwSetCursorPosCallback(m_Window, [](GLFWwindow* window, double xPos, double yPos)
    {
        if(s_EventCount == 9)
            return;

        yPos = s_Height-yPos;

        Event* event = new MouseMovedEvent((float)xPos,(float)yPos);
        s_Events[s_EventCount] = event;
        s_EventCount++;
    });

    glfwSetMouseButtonCallback(m_Window,[](GLFWwindow* window, int button, int action, int mods)
    {
        if(s_EventCount == 9)
            return;
        Event* event;
        if(action == GLFW_PRESS)
        {
            event = new MousePressedEvent(button);
        }
        else if(action == GLFW_RELEASE)
        {
            event = new MouseReleasedEvent(button);
        }
        else
        {
            event = NULL;
        }
        s_Events[s_EventCount] = event;
        s_EventCount++;
    });

    glfwSetKeyCallback(m_Window, [](GLFWwindow* window, int key, int scancode, int action, int mods)
    {
        if(s_EventCount == 9)
            return;
        Event* event;
        if(action == GLFW_PRESS)
        {
            event = new KeyPressedEvent(key);
            s_Events[s_EventCount] = event;
            s_EventCount++;
        }
        else if(action == GLFW_RELEASE)
        {
            event = new KeyReleasedEvent(key);
            s_Events[s_EventCount] = event;
            s_EventCount++;
        }

    });

}

Window::~Window()
{
    glfwTerminate();
}


void Window::Clear() const
{
    glClear(GL_COLOR_BUFFER_BIT);
    glClear(GL_DEPTH_BUFFER_BIT);
}

void Window::SwapBuffers() const
{
    glfwSwapBuffers(m_Window);
    glfwPollEvents();
    glFlush();
}

void Window::HideCursor(bool hide) const
{
    if(hide)
        glfwSetInputMode(m_Window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    if(!hide)
        glfwSetInputMode(m_Window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
}
