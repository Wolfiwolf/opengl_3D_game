#pragma once

enum Direction
{
    NONE = 0,
    UP,
    DOWN,
    LEFT,
    RIGHT
};
