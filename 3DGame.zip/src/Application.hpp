#pragma once

#include "Window.hpp"

#include "scenes/MenuScene.hpp"
#include "scenes/GameScene.hpp"

class Application
{
private:
    static Window* m_Window;

    bool m_Running;

    unsigned int m_SceneIndex;

    static Scene* m_Scenes[10];

public:
    Application();
    ~Application();

    void Run();

    void EventHandler();

};
