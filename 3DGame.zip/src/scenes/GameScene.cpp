#include "GameScene.hpp"


GameScene::GameScene()
    : Scene::Scene()
    , m_ShaderBox(new Shader("shaders/ShaderBox.glsl"))
    , m_ShaderUI(new Shader("shaders/ShaderUI.glsl"))
    , m_TextureFloor(new Texture("res/tilesTexture.jpg"))
    , m_TextureCeiling(new Texture("res/ceilingTexture.jpg"))
    , m_TextureWall(new Texture("res/wallTexture.jpg"))
    , m_TextureLight(new Texture("res/lightTexture.jpg"))
    , m_TextureWood(new Texture("res/woodTexture.jpg"))
    , m_FloorObj ( StaticBoxObject({0.0f,0.0f,0.0f}, {20.0f, 0.1f, 20.0f}, m_ShaderBox, m_TextureFloor, 0.5f, 1.0f))
    , m_CeilingObj ( StaticBoxObject({0.0f,3.0f,0.0f}, {20.0f, 0.1f, 20.0f}, m_ShaderBox, m_TextureCeiling, 0.5f, 1.0f))
    , m_WallLeftObj ( StaticBoxObject({-20.0f,1.5f,0.0f}, {0.2f, 1.5f, 20.0f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_WallRightObj ( StaticBoxObject({20.0f,1.5f,0.0f}, {0.2f, 1.5f, 20.0f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_WallFrontObj ( StaticBoxObject({0.0f,1.5f,-20.0f}, {20.0f, 1.5f, 0.2f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_WallBackObj ( StaticBoxObject({0.0f,1.5f, 20.0f}, {20.0f, 1.5f, 0.2f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_Wall1 (StaticBoxObject({-4.0f,1.5f, 0.0f}, {0.2f, 1.5f, 15.0f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_Wall2 (StaticBoxObject({4.0f,1.5f, 0.0f}, {0.2f, 1.5f, 15.0f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_Wall3 (StaticBoxObject({-2.0f,1.5f, -5.0f}, {2.0f, 1.5f, 0.2f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_Wall4 (StaticBoxObject({2.0f,1.5f, 5.0f}, {2.0f, 1.5f, 0.2f}, m_ShaderBox, m_TextureWall, 0.7f, 1.0f))
    , m_TableObj1(Static3dModelObject("res/3d_models/table.obj", {-2.8f, 1.0f, -4.0f}, {1.0f,1.0f,1.0f}, 1.0f, m_ShaderBox, m_TextureWood, 1.0f, 1.0f))
    , m_TableObj2(Static3dModelObject("res/3d_models/table.obj", { 2.8f, 1.0f,  4.0f}, {1.0f,1.0f,1.0f}, 1.0f, m_ShaderBox, m_TextureWood, 1.0f, 1.0f))
    , m_TableObj3(Static3dModelObject("res/3d_models/table.obj", {19.0f, 1.0f, 19.0f}, {1.0f,1.0f,1.0f}, 1.0f, m_ShaderBox, m_TextureWood, 1.0f, 1.0f))
    , m_TableObj4(Static3dModelObject("res/3d_models/table.obj", {-19.0f, 1.0f, -19.0f}, {1.0f,1.0f,1.0f}, 1.0f, m_ShaderBox, m_TextureWood, 1.0f, 1.0f))
    , m_Robot(Robot({0.0f, 0.7f, -3.0f}, m_ShaderBox, m_TextureLight))
    , m_Light1 (BoxRenderer({-18.0f, 2.9f, 0.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light2 (BoxRenderer({18.0f, 2.9f, 0.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light3 (BoxRenderer({0.0f, 2.9f, -18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light4 (BoxRenderer({0.0f, 2.9f, 18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light5 (BoxRenderer({18.0f, 2.9f, 18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light6 (BoxRenderer({-18.0f, 2.9f, 18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light7 (BoxRenderer({-18.0f, 2.9f, -18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light8 (BoxRenderer({18.0f, 2.9f, -18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light9 (BoxRenderer({0.0f, 2.9f, 0.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light10 (BoxRenderer({18.0f, 2.9f, -18.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light11 (BoxRenderer({0.0f, 2.9f, -10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light12 (BoxRenderer({0.0f, 2.9f, 10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light13 (BoxRenderer({8.0f, 2.9f, 0.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light14 (BoxRenderer({8.0f, 2.9f, -10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light15 (BoxRenderer({8.0f, 2.9f, 10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light16 (BoxRenderer({-8.0f, 2.9f, 0.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light17 (BoxRenderer({-8.0f, 2.9f, -10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Light18 (BoxRenderer({-8.0f, 2.9f, 10.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_AimSightImg(Image("res/aimSight.png", 1.0f, {SCREEN_WIDTH/2, SCREEN_HEIGHT/2}, {20.0f,20.0f}, m_ShaderUI))
    , m_Player(Player(glm::vec3(m_Camera.GetPosition() - glm::vec3(0.0f,1.0f,0.0f))))
{

    m_ShaderUI->Bind();
    m_ShaderUI->SetUnifrom4Mat("u_view_matrix", m_Camera.GetOrthoView());
    m_ShaderUI->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetOrthoProjection());


    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom4Mat("u_view_matrix", m_Camera.GetPerspectiveView());
    m_ShaderBox->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetPerspectiveProjection());


    constexpr const float lightsPos[] =
    {
        -18.0f, 2.4f, 0.0f, 4.0f,
         18.0f, 2.4f, 0.0f, 4.0f,
         0.0f, 2.4f, -18.0f, 4.0f,
         0.0f, 2.4f, 18.0f, 4.0f,
         18.0f, 2.4f, 18.0f, 4.0f,
        -18.0f, 2.4f, 18.0f, 4.0f,
        -18.0f, 2.4f, -18.0f, 4.0f,
         18.0f, 2.4f, -18.0f, 4.0f,
         0.0f, 2.4f,  0.0f, 4.0f,
         0.0f, 2.4f, -10.0f, 4.0f,
         0.0f, 2.4f,  10.0f, 4.0f,
         8.0f, 2.4f,  0.0f, 4.0f,
         8.0f, 2.4f, -10.0f, 4.0f,
         8.0f, 2.4f,  10.0f, 4.0f,
        -8.0f, 2.4f,  0.0f, 4.0f,
        -8.0f, 2.4f, -10.0f, 4.0f,
        -8.0f, 2.4f,  10.0f, 4.0f
    };

    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom1i("u_light_count", 17);
    m_ShaderBox->SetUniform1fv("u_lights_pos", 4 * 17, lightsPos);




}

GameScene::~GameScene()
{

}

void GameScene::Init()
{
    glfwSetInputMode(s_Window->GetWindow(), GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    m_Camera.Reset();

    m_Camera.SetPosition(glm::vec3(0.0f,2.0f,0.0f));
    m_Camera.Turn(0.0f, 0.0f);

    m_Robot.SetPos({0.0f, 0.7f, -3.0f});

    m_KeyPressed_W = false;
    m_KeyPressed_S = false;
    m_KeyPressed_A = false;
    m_KeyPressed_D = false;

    m_PrevMousePosX = s_CursorXPos;
    m_PrevMousePosY = s_CursorYPos;
}

void GameScene::Update()
{

    m_ShaderUI = new Shader("shaders/ShaderUI.glsl");
    m_ShaderUI->Bind();
    m_ShaderUI->SetUnifrom4Mat("u_view_matrix", m_Camera.GetOrthoView());
    m_ShaderUI->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetOrthoProjection());

    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom4Mat("u_view_matrix", m_Camera.GetPerspectiveView());
    m_ShaderBox->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetPerspectiveProjection());

    m_FloorObj.Update();
    m_CeilingObj.Update();
    m_WallLeftObj.Update();
    m_WallRightObj.Update();
    m_WallFrontObj.Update();
    m_WallBackObj.Update();

    m_Wall1.Update();
    m_Wall2.Update();

    m_Wall3.Update();
    m_Wall4.Update();

    m_TableObj1.Update();
    m_TableObj2.Update();
    m_TableObj3.Update();
    m_TableObj4.Update();

    m_Robot.Update();

    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom1i("u_is_light", 1);

    m_Light1.Render();
    m_Light2.Render();
    m_Light3.Render();
    m_Light4.Render();
    m_Light5.Render();
    m_Light6.Render();
    m_Light7.Render();
    m_Light8.Render();
    m_Light9.Render();
    m_Light10.Render();
    m_Light11.Render();
    m_Light12.Render();
    m_Light13.Render();
    m_Light14.Render();
    m_Light15.Render();
    m_Light16.Render();
    m_Light17.Render();
    m_Light18.Render();

    m_ShaderBox->SetUnifrom1i("u_is_light", 0);

    //UI
    glDisable(GL_DEPTH_TEST);

    m_AimSightImg.Render();

    glEnable(GL_DEPTH_TEST);


    m_Player = Player(glm::vec3(m_Camera.GetPosition()));
    m_Player.Update();

    //COLLIDER

    m_Robot.Follow(m_Player);


    m_Player.Collider(m_WallFrontObj);
    m_Player.Collider(m_WallBackObj);
    m_Player.Collider(m_WallLeftObj);
    m_Player.Collider(m_WallRightObj);
    m_Player.Collider(m_Wall1);
    m_Player.Collider(m_Wall2);
    m_Player.Collider(m_Wall3);
    m_Player.Collider(m_Wall4);
    m_Player.Collider(m_TableObj1);
    m_Player.Collider(m_TableObj2);
    m_Player.Collider(m_TableObj3);
    m_Player.Collider(m_TableObj4);
    m_Player.Collider(m_Robot);

    m_Camera.SetObstacles(m_Player.GetObstacleFront(), m_Player.GetObstacleBack(), m_Player.GetObstacleLeft(), m_Player.GetObstacleRight());


    float xTurn = s_CursorXPos - m_PrevMousePosX;
    float yTurn = s_CursorYPos - m_PrevMousePosY;

    m_PrevMousePosX = s_CursorXPos;
    m_PrevMousePosY = s_CursorYPos;

    m_Camera.Turn(xTurn * 0.1f, yTurn * 0.1f);

    float speed = 0.1f;

    if(m_KeyPressed_W)
        m_Camera.Move(UP, speed);
    if(m_KeyPressed_S)
        m_Camera.Move(DOWN, speed);
    if(m_KeyPressed_A)
        m_Camera.Move(LEFT, speed);
    if(m_KeyPressed_D)
        m_Camera.Move(RIGHT, speed);

}


//ON EVENTS
void GameScene::OnMouseMovedEvent(MouseMovedEvent* event)
{

}
void GameScene::OnMousePressedEvent(MousePressedEvent* event)
{

}
void GameScene::OnMouseReleasedEvent(MouseReleasedEvent* event)
{

}
void GameScene::OnKeyPressedEvent(KeyPressedEvent* event)
{
    if(event->keyCode == GLFW_KEY_W)
        m_KeyPressed_W = true;
    if(event->keyCode == GLFW_KEY_S)
        m_KeyPressed_S = true;
    if(event->keyCode == GLFW_KEY_A)
        m_KeyPressed_A = true;
    if(event->keyCode == GLFW_KEY_D)
        m_KeyPressed_D = true;

    if(event->keyCode == GLFW_KEY_ESCAPE)
        m_ChangeScene = 0;
}
void GameScene::OnKeyReleasedEvent(KeyReleasedEvent* event)
{
    if(event->keyCode == GLFW_KEY_W)
        m_KeyPressed_W = false;
    if(event->keyCode == GLFW_KEY_S)
        m_KeyPressed_S = false;
    if(event->keyCode == GLFW_KEY_A)
        m_KeyPressed_A = false;
    if(event->keyCode == GLFW_KEY_D)
        m_KeyPressed_D = false;
}
