#pragma once

#include "Scene.hpp"

class GameScene : public Scene
{
private:
    Shader* m_ShaderBox;
    Shader* m_ShaderUI;

    Texture* m_TextureFloor;
    Texture* m_TextureCeiling;
    Texture* m_TextureWall;
    Texture* m_TextureLight;
    Texture* m_TextureWood;


    //OBJECTS

    StaticBoxObject m_FloorObj;
    StaticBoxObject m_CeilingObj;
    StaticBoxObject m_WallLeftObj;
    StaticBoxObject m_WallRightObj;
    StaticBoxObject m_WallFrontObj;
    StaticBoxObject m_WallBackObj;

    StaticBoxObject m_Wall1;
    StaticBoxObject m_Wall2;
    StaticBoxObject m_Wall3;
    StaticBoxObject m_Wall4;

    Static3dModelObject m_TableObj1;
    Static3dModelObject m_TableObj2;
    Static3dModelObject m_TableObj3;
    Static3dModelObject m_TableObj4;

    Robot m_Robot;

    //LIGHTS

    BoxRenderer m_Light1;
    BoxRenderer m_Light2;
    BoxRenderer m_Light3;
    BoxRenderer m_Light4;
    BoxRenderer m_Light5;
    BoxRenderer m_Light6;
    BoxRenderer m_Light7;
    BoxRenderer m_Light8;
    BoxRenderer m_Light9;
    BoxRenderer m_Light10;
    BoxRenderer m_Light11;
    BoxRenderer m_Light12;
    BoxRenderer m_Light13;
    BoxRenderer m_Light14;
    BoxRenderer m_Light15;
    BoxRenderer m_Light16;
    BoxRenderer m_Light17;
    BoxRenderer m_Light18;

    //UI

    Image m_AimSightImg;

    //CONSTROLS

    Player m_Player;

    bool m_KeyPressed_W;
    bool m_KeyPressed_S;
    bool m_KeyPressed_A;
    bool m_KeyPressed_D;

    int m_PrevMousePosX;
    int m_PrevMousePosY;

public:
    GameScene();
    ~GameScene();

    void Init() override;

    void Update() override;



    //ON EVENTS
    void OnMouseMovedEvent(MouseMovedEvent* event) override;
    void OnMousePressedEvent(MousePressedEvent* event) override;
    void OnMouseReleasedEvent(MouseReleasedEvent* event) override;
    void OnKeyPressedEvent(KeyPressedEvent* event) override;
    void OnKeyReleasedEvent(KeyReleasedEvent* event) override;

};
