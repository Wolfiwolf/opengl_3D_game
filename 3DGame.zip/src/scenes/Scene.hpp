#pragma once

#include "../render_objects/Camera.hpp"
#include "../render_objects/Image.hpp"
#include "../render_objects/BoxRenderer.hpp"
#include "../render_objects/Model3D.hpp"

#include "../game_objects/StaticBoxObject.hpp"
#include "../game_objects/Static3dModelObject.hpp"
#include "../game_objects/Player.hpp"
#include "../game_objects/Robot.hpp"

#include "../events/MouseEvents.hpp"
#include "../events/KeyEvents.hpp"

#include "../Window.hpp"



class Scene
{
private:
    static int s_FrameBufferWidth;
    static int s_FrameBufferHeight;
protected:
    int m_ChangeScene;

    static int s_CursorXPos;
    static int s_CursorYPos;
    static Window* s_Window;

    Camera m_Camera;

public:
    Scene()
        :m_ChangeScene(-1), m_Camera(Camera(s_FrameBufferWidth, s_FrameBufferHeight))
    {

    }
    virtual ~Scene()
    {

    }

    virtual void Init() = 0;

    virtual void Update() = 0;

    inline bool ChangeScene(unsigned int& sceneIndex)
    {
        if(m_ChangeScene == -1)
            return false;

        sceneIndex = m_ChangeScene;
        m_ChangeScene = -1;

        return true;
    }

    static void SetCursorPos(float x, float y)
    {
        s_CursorXPos = x;
        s_CursorYPos = y;
    }

    static void SetFrameBufferSize(float width, float height)
    {
        s_FrameBufferWidth = width;
        s_FrameBufferHeight = height;
    }

    static void SetWindow(Window* window)
    {
        s_Window = window;
    }

    //ON EVENTS
    virtual void OnMouseMovedEvent(MouseMovedEvent* event) = 0;
    virtual void OnMousePressedEvent(MousePressedEvent* event) = 0;
    virtual void OnMouseReleasedEvent(MouseReleasedEvent* event) = 0;
    virtual void OnKeyPressedEvent(KeyPressedEvent* event) = 0;
    virtual void OnKeyReleasedEvent(KeyReleasedEvent* event) = 0;

};
