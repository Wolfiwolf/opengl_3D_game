#include "MenuScene.hpp"

MenuScene::MenuScene()
    : Scene::Scene()
    , m_ShaderUI(new Shader("shaders/ShaderUI.glsl"))
    , m_ShaderBox(new Shader("shaders/ShaderBox.glsl"))
    , m_TextureFloor(new Texture("res/tilesTexture.jpg"))
    , m_TextureCeiling(new Texture("res/ceilingTexture.jpg"))
    , m_TextureWall(new Texture("res/wallTexture.jpg"))
    , m_TextureLight(new Texture("res/lightTexture.jpg"))
    , m_TextureWood(new Texture("res/woodTexture.jpg"))
    , m_Light1(BoxRenderer({-2.0f, 2.9f, -2.0f}, {0.3f,0.1f,0.3f}, m_ShaderBox, m_TextureLight, 1.0f, 1.0f))
    , m_Floor (BoxRenderer({0.0f,0.0f,0.0f}, {10.0f,0.1f,5.0f}, m_ShaderBox, m_TextureFloor, 0.5f, 1.0f))
    , m_Ceiling (BoxRenderer({0.0f,3.0f,0.0f}, {10.0f,0.1f,5.0f}, m_ShaderBox, m_TextureCeiling, 0.5f, 1.0f))
    , m_WallLeft (BoxRenderer({-5.0f, 1.5f, 0.0f}, {0.1f, 1.5f,10.0f}, m_ShaderBox, m_TextureWall, 0.5f, 0.7f))
    , m_WallForward (BoxRenderer({0.0f,1.5f, -5.0f}, {5.0f,1.5f,0.1f}, m_ShaderBox, m_TextureWall, 0.5f, 0.7f))
    , m_Model(Model3D("res/3d_models/table.obj", {-3.5f,1.2f,-4.0f}, 1.2f, m_ShaderBox, m_TextureWood))
    , m_PlayButtonImg (Image("res/redButton.png", 1.0f, {SCREEN_WIDTH/4, SCREEN_HEIGHT * 3/4}, {150.0f, 60.0f}, m_ShaderUI))
    , m_PlayButtonFocusedImg(Image("res/greenButton.png", 1.0f, {SCREEN_WIDTH/4, SCREEN_HEIGHT * 3/4}, {150.0f, 60.0f}, m_ShaderUI))
{

    m_ShaderUI->Bind();
    m_ShaderUI->SetUnifrom4Mat("u_view_matrix", m_Camera.GetOrthoView());
    m_ShaderUI->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetOrthoProjection());

    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom4Mat("u_view_matrix", m_Camera.GetPerspectiveView());
    m_ShaderBox->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetPerspectiveProjection());


    constexpr const float lightsPos[] =
    {
        -2.0f, 2.4f, -2.0f, 4.0f
    };

    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom1i("u_light_count", 1);
    m_ShaderBox->SetUniform1fv("u_lights_pos", 4, lightsPos);


}

MenuScene::~MenuScene()
{

}

void MenuScene::Init()
{
    glfwSetInputMode(s_Window->GetWindow(), GLFW_CURSOR, GLFW_CURSOR_NORMAL);

    m_Camera.Reset();

    m_Camera.SetPosition(glm::vec3(1.0f,2.5f,2.0f));
    m_Camera.Turn(-60.0f, -15.0f);
}

void MenuScene::Update()
{
    m_ShaderUI->Bind();
    m_ShaderUI->SetUnifrom4Mat("u_view_matrix", m_Camera.GetOrthoView());
    m_ShaderUI->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetOrthoProjection());


    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom4Mat("u_view_matrix", m_Camera.GetPerspectiveView());
    m_ShaderBox->SetUnifrom4Mat("u_projection_matrix", m_Camera.GetPerspectiveProjection());


    m_Floor.Render();
    m_Ceiling.Render();
    m_WallLeft.Render();
    m_WallForward.Render();
    m_Model.Render();


    m_ShaderBox->Bind();
    m_ShaderBox->SetUnifrom1i("u_is_light", 1);

    m_Light1.Render();

    m_ShaderBox->SetUnifrom1i("u_is_light", 0);

    glDisable(GL_DEPTH_TEST);

    if(s_CursorXPos < SCREEN_WIDTH/4 + 150 && s_CursorXPos > SCREEN_WIDTH/4 - 150)
    {
        if(s_CursorYPos < SCREEN_HEIGHT*3/4 + 60 && s_CursorYPos > SCREEN_HEIGHT*3/4 - 60)
            m_PlayButtonFocusedImg.Render();
        else
            m_PlayButtonImg.Render();
    }
    else
        m_PlayButtonImg.Render();


    glEnable(GL_DEPTH_TEST);


}



//ON EVENTS
void MenuScene::OnMouseMovedEvent(MouseMovedEvent* event)
{

}
void MenuScene::OnMousePressedEvent(MousePressedEvent* event)
{
    if(event->button == 0)
    {
        if(s_CursorXPos < SCREEN_WIDTH/4 + 150 && s_CursorXPos > SCREEN_WIDTH/4 - 150)
        {
            if(s_CursorYPos < SCREEN_HEIGHT*3/4 + 60 && s_CursorYPos > SCREEN_HEIGHT*3/4 - 60)
            {
                m_ChangeScene = 1;
            }
        }
    }
}
void MenuScene::OnMouseReleasedEvent(MouseReleasedEvent* event)
{

}
void MenuScene::OnKeyPressedEvent(KeyPressedEvent* event)
{

}
void MenuScene::OnKeyReleasedEvent(KeyReleasedEvent* event)
{

}
