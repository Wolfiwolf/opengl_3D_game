#pragma once

#include "Scene.hpp"


class MenuScene : public Scene
{
private:
    Shader* m_ShaderUI;
    Shader* m_ShaderBox;

    Texture* m_TextureFloor;
    Texture* m_TextureCeiling;
    Texture* m_TextureWall;
    Texture* m_TextureLight;
    Texture* m_TextureWood;

    //LIGHTS

    BoxRenderer m_Light1;

    //OBJECTS

    BoxRenderer m_Floor;
    BoxRenderer m_Ceiling;
    BoxRenderer m_WallLeft;
    BoxRenderer m_WallForward;

    Model3D m_Model;


    //UI

    Image m_PlayButtonImg;
    Image m_PlayButtonFocusedImg;



public:
    MenuScene();
    ~MenuScene();

    void Init() override;

    void Update() override;



    //ON EVENTS
    void OnMouseMovedEvent(MouseMovedEvent* event) override;
    void OnMousePressedEvent(MousePressedEvent* event) override;
    void OnMouseReleasedEvent(MouseReleasedEvent* event) override;
    void OnKeyPressedEvent(KeyPressedEvent* event) override;
    void OnKeyReleasedEvent(KeyReleasedEvent* event) override;


};
