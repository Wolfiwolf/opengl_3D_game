#include "Application.hpp"


int Scene::s_FrameBufferWidth = 0;
int Scene::s_FrameBufferHeight = 0;
int Scene::s_CursorXPos = 0;
int Scene::s_CursorYPos = 0;
Window* Scene::s_Window;

Window* Application::m_Window;
Scene* Application::m_Scenes[10];


Application::Application()
{

}

Application::~Application()
{

}

void Application::Run()
{
    system("xset r off");
    m_Window = new Window("3D Game", SCREEN_WIDTH, SCREEN_HEIGHT);

    Scene::SetFrameBufferSize(m_Window->GetFrameBufferWidth(),m_Window->GetFrameBufferHeight());
    Scene::SetWindow(m_Window);


    m_Scenes[0] = new MenuScene();
    m_Scenes[1] = new GameScene();

    m_SceneIndex = 0;

    m_Scenes[m_SceneIndex]->Init();


    m_Running = true;
    while(m_Running)
    {
        m_Window->Clear();


        m_Scenes[m_SceneIndex]->Update();


        if(m_Scenes[m_SceneIndex]->ChangeScene(m_SceneIndex))
        {

            m_Scenes[m_SceneIndex]->Init();

        }

        m_Window->SwapBuffers();

        EventHandler();

    }
}

void Application::EventHandler()
{

    for(unsigned int i = 0; i < m_Window->s_EventCount; i++)
    {
        Event* event =m_Window->s_Events[i];

        switch(event->GetEventType())
        {
            case WINDOW_CLOSED:
                m_Running = false;
                glfwTerminate();
                system("xset r on");
                break;

            case MOUSE_MOVED:
                Scene::SetCursorPos(((MouseMovedEvent*) event)->xPos,((MouseMovedEvent*) event)->yPos);
                m_Scenes[m_SceneIndex]->OnMouseMovedEvent((MouseMovedEvent*) event);
                break;
            case MOUSE_BUTTON_PRESSED:
                m_Scenes[m_SceneIndex]->OnMousePressedEvent((MousePressedEvent*) event);
                break;
            case MOUSE_BUTTON_RELEASED:
                m_Scenes[m_SceneIndex]->OnMouseReleasedEvent((MouseReleasedEvent*) event);
                break;
            case KEY_PRESSED:
                m_Scenes[m_SceneIndex]->OnKeyPressedEvent((KeyPressedEvent*) event);
                break;
            case KEY_RELEASED:
                m_Scenes[m_SceneIndex]->OnKeyReleasedEvent((KeyReleasedEvent*) event);
                break;
        }

        delete event;

    }

    m_Window->s_EventCount = 0;


}
