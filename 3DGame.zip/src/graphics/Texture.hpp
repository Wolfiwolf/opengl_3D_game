#pragma once

#include "../vendor/glad/glad.h"
#include "../vendor/stb_image/stb_image.hpp"

#include <iostream>
#include <string>

class Texture
{
private:
    unsigned int m_RendererID;

    int m_Width;
    int m_Height;
    int m_BPP;

    unsigned char* m_LocalBuffer;

    unsigned int m_TextureIndex;

    static unsigned int s_TextureCount;

public:
    Texture();
    Texture(const std::string& filepath);
    ~Texture();

    void Bind() const;
    void UnBind() const;

    inline unsigned int GetTextureIndex() const
    {
        return m_TextureIndex;
    }

};
