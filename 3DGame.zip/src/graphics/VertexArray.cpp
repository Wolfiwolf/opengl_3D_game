#include "VertexArray.hpp"


VertexArray::VertexArray()
    :m_RenderedID(0)
{
    glGenVertexArrays(1, &m_RenderedID);
    glBindVertexArray(m_RenderedID);
}

VertexArray::~VertexArray()
{

}


void VertexArray::Bind() const
{
    glBindVertexArray(m_RenderedID);
}

void VertexArray::UnBind() const
{
    glBindVertexArray(0);
}

void VertexArray::AddBuffer(const VertexBuffer& vb,const VertexBufferLayout &layout)
{
    Bind();
    vb.Bind();
    std::vector<VertexBufferLayoutElement> elements = layout.GetElements();

    const void* offsets[19];

    offsets[0] = (const void*)0;
    offsets[1] = (const void*)(1*4);
    offsets[2] = (const void*)(2*4);
    offsets[3] = (const void*)(3*4);
    offsets[4] = (const void*)(4*4);
    offsets[5] = (const void*)(5*4);
    offsets[6] = (const void*)(6*4);
    offsets[7] = (const void*)(7*4);
    offsets[8] = (const void*)(8*4);
    offsets[9] = (const void*)(9*4);
    offsets[10] = (const void*)(10*4);
    offsets[11] = (const void*)(11*4);
    offsets[12] = (const void*)(12*4);
    offsets[13] = (const void*)(13*4);
    offsets[14] = (const void*)(14*4);
    offsets[15] = (const void*)(15*4);
    offsets[16] = (const void*)(16*4);
    offsets[17] = (const void*)(17*4);
    offsets[18] = (const void*)(18*4);



    for(unsigned int i = 0; i < elements.size(); i++)
    {
        glVertexAttribPointer(i, elements[i].count , GL_FLOAT, GL_FALSE, layout.GetStride(), offsets[elements[i].offset/4]);
        glEnableVertexAttribArray(i);
    }

}
