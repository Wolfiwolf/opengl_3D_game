#pragma once

#include "../vendor/glad/glad.h"
#include <GLFW/glfw3.h>

class VertexBuffer
{
private:
    unsigned int m_RendererID;

public:
    VertexBuffer(unsigned int size, float* verticies);
    ~VertexBuffer();

    void Bind() const;

    void UnBind() const;

};
