#pragma once

#include "../vendor/glad/glad.h"

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

#include "../vendor/glm/gtc/quaternion.hpp"

struct ShaderSource
{
    std::string vertexSource;
    std::string fragmentSource;

};

class Shader
{
private:
    unsigned int m_RendererID;

public:
    Shader(const std::string& filepath);
    ~Shader();

    void Bind() const;
    void UnBind() const;

    void SetUnifrom3f(const std::string& name, const glm::vec3& vector);
    void SetUnifrom1i(const std::string& name, int value);
    void SetUnifrom4Mat(const std::string& name, const glm::mat4& matrix);
    void SetUniform1fv(const std::string& name, unsigned int count, const float* array);
private:
    int GetUnifromLocation(const std::string& name);

    ShaderSource GetShaderSource(const std::string& filepath) const;
    unsigned int CreateShader(const std::string& vertexSrc, const std::string& fragmentSrc);
    unsigned int CompileShader(const std::string& shaderSource, unsigned int type);



};
