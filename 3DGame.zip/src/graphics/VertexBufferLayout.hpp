#pragma once


#include <iostream>
#include <vector>

struct VertexBufferLayoutElement
{
    unsigned int count;
    unsigned int offset;


    VertexBufferLayoutElement(unsigned int count, unsigned int size)
        :count(count), offset(size)
    {

    }

};

class VertexBufferLayout
{
private:
    std::vector<VertexBufferLayoutElement> m_Elements;
    unsigned int m_Stride;

public:
    VertexBufferLayout()
        :m_Stride(0)
    {

    }
    ~VertexBufferLayout()
    {

    }

    template<typename T>
    inline void PushBytes(unsigned int count)
    {
        m_Elements.push_back({count, m_Stride});
        m_Stride += count * sizeof(T);
    }


    inline unsigned int GetStride() const
    {
        return m_Stride;
    }

    inline const std::vector<VertexBufferLayoutElement>& GetElements() const
    {
        return m_Elements;
    }

};
