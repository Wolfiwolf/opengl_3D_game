#pragma once

#include "../vendor/glad/glad.h"
#include <GLFW/glfw3.h>

#include "VertexBufferLayout.hpp"
#include "VertexBuffer.hpp"


class VertexArray
{
private:
    unsigned int m_RenderedID;

public:
    VertexArray();
    ~VertexArray();

    void Bind() const;

    void UnBind() const;

    void AddBuffer(const VertexBuffer& vb, const VertexBufferLayout& layout);

};
