#include "Shader.hpp"


Shader::Shader(const std::string& filepath)
    :m_RendererID(0)
{
    ShaderSource shaderSrc = GetShaderSource(filepath);
    m_RendererID = CreateShader(shaderSrc.vertexSource, shaderSrc.fragmentSource);


    glUseProgram(m_RendererID);
}

Shader::~Shader()
{

}

void Shader::Bind() const
{
    glUseProgram(m_RendererID);
}

void Shader::UnBind() const
{
    glUseProgram(0);
}

// SET UNIFORM

void Shader::SetUnifrom3f(const std::string &name, const glm::vec3 &vector)
{
    glUniform3f(GetUnifromLocation(name), vector.x,vector.y,vector.z);
}

void Shader::SetUnifrom1i(const std::string &name, int value)
{
    glUniform1i(GetUnifromLocation(name), value);
}

void Shader::SetUnifrom4Mat(const std::string &name, const glm::mat4& matrix)
{
    glUniformMatrix4fv(GetUnifromLocation(name),1, GL_FALSE, &matrix[0][0]);
}

void Shader::SetUniform1fv(const std::string &name, unsigned int count, const float *array)
{
    glUniform1fv(GetUnifromLocation(name), count, array);
}


int Shader::GetUnifromLocation(const std::string &name)
{
    int location = glGetUniformLocation(m_RendererID, name.c_str());

    if(location == -1)
        std::cout << "Uniform " << name << " doesn't exist!\n";

    return location;
}

//PRIVATE

ShaderSource Shader::GetShaderSource(const std::string& filepath) const
{

    enum ShaderType
    {
        NONE = -1,
        VERTEX = 0,
        FRAGMENT = 1
    };

    std::stringstream ss[2];

    std::string line;

    std::ifstream shaderFile(filepath.c_str());

    if(!shaderFile.is_open())
    {
        std::cout << "Can't open shader file! => " << filepath << "\n";
        return {NULL, NULL};
    }

    ShaderType type = NONE;

    while(std::getline(shaderFile, line))
    {
        if(line.find("#SHADER") != std::string::npos)
        {
            if(line.find("VERTEX") != std::string::npos)
                type = VERTEX;

            else if(line.find("FRAGMENT") != std::string::npos)
                type = FRAGMENT;
        }
        else
        {
            ss[type] << line << "\n";
        }
    }




    return {ss[0].str(), ss[1].str()};
}



unsigned int Shader::CreateShader(const std::string &vertexSrc,
                                    const std::string &fragmentSrc)
{
    unsigned int vertex;
    unsigned int fragment;

    vertex = CompileShader(vertexSrc, GL_VERTEX_SHADER);
    fragment = CompileShader(fragmentSrc, GL_FRAGMENT_SHADER);

    unsigned int id = glCreateProgram();

    glAttachShader(id,vertex);
    glAttachShader(id,fragment);
    glLinkProgram(id);

    glDeleteShader(vertex);
    glDeleteShader(fragment);
    return id;
}

unsigned int Shader::CompileShader(const std::string &shaderSource, unsigned int type)
{
    unsigned int shader = glCreateShader(type);

    const char* src = shaderSource.c_str();

    glShaderSource(shader, 1, &src, NULL);
    glCompileShader(shader);

    int succes;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &succes);
    if(!succes)
    {
        char infoLog[512];
        glGetShaderInfoLog(shader, 512, NULL, infoLog);
        std::cout << "Failed to compile " << (type == GL_VERTEX_SHADER ? "VERTEX":"FRAGMENT") << " shader!\n\n" << infoLog << "\n";
    }


    return shader;
}
