#pragma once

#include "../vendor/glad/glad.h"
#include <GLFW/glfw3.h>

class IndexBuffer
{
private:
    unsigned int m_RendererID;

public:
    IndexBuffer(unsigned int count, unsigned int* indicies);
    ~IndexBuffer();

    void Bind() const;

    void UnBind() const;

};
