#include "VertexBuffer.hpp"


VertexBuffer::VertexBuffer(unsigned int size, float* verticies)
{
    glGenBuffers(1, &m_RendererID);
    glBindBuffer(GL_ARRAY_BUFFER, m_RendererID);
    glBufferData(GL_ARRAY_BUFFER, size, verticies, GL_STATIC_DRAW);
}

VertexBuffer::~VertexBuffer()
{

}


void VertexBuffer::Bind() const
{
    glBindBuffer(GL_ARRAY_BUFFER, m_RendererID);
}

void VertexBuffer::UnBind() const
{
    glBindBuffer(GL_ARRAY_BUFFER, 0);
}
