#pragma once

#include "vendor/glad/glad.h"
#include <GLFW/glfw3.h>

#include <iostream>
#include <string>

#include "events/WindowEvents.hpp"
#include "events/MouseEvents.hpp"
#include "events/KeyEvents.hpp"

class Window
{
private:
    int m_FrameBufferWidth;
    int m_FrameBufferHeight;
    GLFWwindow* m_Window;

    static unsigned int s_Width;
    static unsigned int s_Height;

public:
    static unsigned int s_EventCount;
    static Event* s_Events[10];

    Window(const std::string& title, unsigned int width, unsigned int height);
    ~Window();

    void Clear() const;

    void SwapBuffers() const;

    void HideCursor(bool hide) const;

    inline GLFWwindow* GetWindow() const
    {
        return m_Window;
    }

    inline int GetFrameBufferWidth() const
    {
        return m_FrameBufferWidth;
    }
    inline int GetFrameBufferHeight() const
    {
        return m_FrameBufferHeight;
    }






};
