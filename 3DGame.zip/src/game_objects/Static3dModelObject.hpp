#pragma once

#include "GameObject.hpp"
#include "../render_objects/Model3D.hpp"

class Static3dModelObject : public GameObject
{
private:
     Model3D m_Model;

public:
    Static3dModelObject();
    Static3dModelObject(const std::string& filepath, const glm::vec3& position, const glm::vec3& size, float scale, Shader* shader, Texture* texture, float texScale, float dimm);
    ~Static3dModelObject();

    void Update();

    void RotateRenderer(char axis, float degrees);

};
