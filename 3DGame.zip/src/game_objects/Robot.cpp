#include "Robot.hpp"

Robot::Robot()
    : GameObjectCollider::GameObjectCollider({0.0f, 0.0f, 0.0f}, {0.3f,1.0f,0.2f})
{

}

Robot::Robot(const glm::vec3& position, Shader* shader, Texture* texture)
    : GameObjectCollider::GameObjectCollider(position, {0.3f,1.0f,0.2f})
    , m_Model(Model3D("res/3d_models/robo.obj", position, 0.008f, shader, texture))
{
    m_Model.Rotate('y', 180);
}

Robot::~Robot()
{

}

void Robot::Update()
{
    m_Model.Render();
}

void Robot::Follow(const GameObject &obj)
{
    MoveToObject(obj);
    TurnToObject(obj);
}

//PRIVATE


void Robot::TurnToObject(const GameObject &obj)
{
    static float s_Angle;

    const glm::vec3& objPos = obj.GetPos();

    const glm::vec3 distance = objPos - m_Position;

    const float linearDistance = sqrt(powf(distance.x,2) + powf(distance.z,2));

    s_Angle = glm::degrees(asin(distance.z / linearDistance)) + 90;

    if(m_Position.x < objPos.x)
        s_Angle = -s_Angle;


    m_Model.Rotate('y', s_Angle);

}

void Robot::MoveToObject(const GameObject &obj)
{
    const glm::vec3& objPos = obj.GetPos();

    const glm::vec3 distance = objPos - m_Position;

    if(abs(distance.x) < 3 && abs(distance.z) < 3)
    {
        m_Model.SetPos(m_Position);
        Walk(true);
        return;
    }

    m_Position.x += distance.x * 0.01f;
    m_Position.z += distance.z * 0.01f;

    Walk(false);

    m_Model.SetPos(m_Position);


}

void Robot::Walk(bool stop)
{
    static unsigned int s_FrameCounter = 0;
    static Direction s_Dir = DOWN;
    static bool s_Stop = false;



    if(stop)
    {
        if(s_Stop)
            return;
        else
        {
            if(s_Dir == UP)
            {
                m_Position.y -= 0.08f;
                s_Dir = DOWN;
            }
            s_Stop = true;
            s_FrameCounter = 0;
            return;
        }

    }
    else
    {
        s_Stop = false;
    }

    s_FrameCounter++;


    if(s_FrameCounter % 10 == 0)
    {
        if(s_Dir == DOWN)
        {
            m_Position.y += 0.08f;
            s_Dir = UP;
        }
        else
        {
            m_Position.y -= 0.08f;
            s_Dir = DOWN;
        }
    }

    if(s_FrameCounter == 1000)
        s_FrameCounter = 0;


}
