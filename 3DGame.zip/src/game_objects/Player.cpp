#include "Player.hpp"

Player::Player()
    :GameObjectCollider::GameObjectCollider(glm::vec3(0.0f), {0.2f, 1.0f, 0.2f})
{

}

Player::Player(const glm::vec3& position)
    :GameObjectCollider::GameObjectCollider(position, {0.2f, 1.0f, 0.2f})
{

}

Player::~Player()
{

}

void Player::Update()
{
    GameObjectCollider::Update();

}
