#pragma once

#include "GameObject.hpp"

class GameObjectCollider : public GameObject
{
protected:
    bool m_ObstacleFront;
    bool m_ObstacleBack;
    bool m_ObstacleLeft;
    bool m_ObstacleRight;

public:
    GameObjectCollider(const glm::vec3& position, const glm::vec3& size);

    virtual ~GameObjectCollider();


    void Collider(const GameObject& gameObject);

protected:
    virtual void Update();


};
