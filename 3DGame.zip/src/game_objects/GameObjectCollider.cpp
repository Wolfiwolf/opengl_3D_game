#include "GameObjectCollider.hpp"

GameObjectCollider::GameObjectCollider(const glm::vec3& position, const glm::vec3& size)
    :GameObject::GameObject(position, size)
    , m_ObstacleFront(false)
    , m_ObstacleBack(false)
    , m_ObstacleLeft(false)
    , m_ObstacleRight(false)
{

}

GameObjectCollider::~GameObjectCollider()
{

}

void GameObjectCollider::Update()
{
    m_ObstacleFront = false;
    m_ObstacleBack = false;
    m_ObstacleLeft = false;
    m_ObstacleRight = false;
}

void GameObjectCollider::Collider(const GameObject &gameObject)
{
    const glm::vec3& objPos = gameObject.GetPos();
    const glm::vec3& objSize = gameObject.GetSize();

    glm::vec3 distance = abs(objPos - m_Position);

    if(distance.x > objSize.x + 1.0f && distance.z > objSize.z + 1.0f )
        return;

    if(m_Position.x > objPos.x)
    {
        if(objPos.x + objSize.x > m_Position.x - m_Size.x)
        {
            if(m_Position.z > objPos.z)
            {
                if(m_Position.z - m_Size.z + 0.1f < objPos.z + objSize.z)
                {
                    m_ObstacleLeft = true;
                }
            }
            else if(m_Position.z < objPos.z)
            {
                if(m_Position.z + m_Size.z - 0.1f > objPos.z - objSize.z)
                {
                    m_ObstacleLeft = true;
                }
            }

        }
    }

    else
    {
        if(objPos.x - objSize.x < m_Position.x + m_Size.x)
        {
            if(m_Position.z > objPos.z)
            {
                if(m_Position.z - m_Size.z + 0.1f < objPos.z + objSize.z)
                {
                    m_ObstacleRight = true;
                }
            }
            else if(m_Position.z < objPos.z)
            {
                if(m_Position.z + m_Size.z - 0.1f > objPos.z - objSize.z)
                {
                    m_ObstacleRight = true;
                }
            }
        }
    }

    if(m_Position.z > objPos.z)
    {
        if(objPos.z + objSize.z > m_Position.z - m_Size.z)
        {
            if(m_Position.x > objPos.x)
            {
                if(m_Position.x - m_Size.x + 0.1f  < objPos.x + objSize.x)
                {
                    m_ObstacleFront = true;
                }
            }
            else if(m_Position.x < objPos.x)
            {
                if(m_Position.x + m_Size.x - 0.1f > objPos.x - objSize.x)
                {
                    m_ObstacleFront = true;
                }
            }
        }
    }
    else
    {
        if(objPos.z - objSize.z < m_Position.z + m_Size.z)
        {
            if(m_Position.x > objPos.x)
            {
                if(m_Position.x - m_Size.x + 0.1f  < objPos.x + objSize.x)
                {
                    m_ObstacleBack = true;
                }
            }
            else if(m_Position.x < objPos.x)
            {
                if(m_Position.x + m_Size.x - 0.1f > objPos.x - objSize.x)
                {
                    m_ObstacleBack = true;
                }
            }
        }
    }

}
