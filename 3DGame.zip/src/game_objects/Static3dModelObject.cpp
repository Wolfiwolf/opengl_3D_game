#include "Static3dModelObject.hpp"

Static3dModelObject::Static3dModelObject()
    :GameObject::GameObject(glm::vec3(0.0f), glm::vec3(0.0f))
{

}

Static3dModelObject::Static3dModelObject(const std::string& filepath, const glm::vec3& position, const glm::vec3& size, float scale, Shader* shader, Texture* texture, float texScale, float dimm)
    :GameObject::GameObject(position, size)
{
    m_Model = Model3D(filepath, position, scale, shader, texture);

}

Static3dModelObject::~Static3dModelObject()
{

}

void Static3dModelObject::Update()
{
    m_Model.Render();
}

void Static3dModelObject::RotateRenderer(char axis, float degrees)
{
    m_Model.Rotate(axis, degrees);
}
