#pragma once

#include "GameObjectCollider.hpp"
#include "../render_objects/Model3D.hpp"


class Robot : public GameObjectCollider
{
private:
    Model3D m_Model;

public:
    Robot();
    Robot(const glm::vec3& position, Shader* shader, Texture* texture);
    ~Robot();


    void Update();

    void Follow(const GameObject& obj);

private:
    void TurnToObject(const GameObject& obj);

    void MoveToObject(const GameObject& obj);

    void Walk(bool stop);


};
