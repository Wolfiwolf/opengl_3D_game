#include "StaticBoxObject.hpp"

StaticBoxObject::StaticBoxObject()
    :GameObject::GameObject(glm::vec3(0.0f), glm::vec3(0.0f))
{

}

StaticBoxObject::StaticBoxObject(const glm::vec3& position, const glm::vec3& size,Shader *shader, Texture *texture, float texScale, float dimm)
    :GameObject::GameObject(position, size)
{
    m_BoxRenderer = BoxRenderer(position, size, shader, texture, texScale, dimm);

}

StaticBoxObject::~StaticBoxObject()
{

}

void StaticBoxObject::Update()
{
    m_BoxRenderer.Render();
}

void StaticBoxObject::SetPos(const glm::vec3 &position)
{
    GameObject::SetPos(position);
    m_BoxRenderer.SetPosition(position);
}
