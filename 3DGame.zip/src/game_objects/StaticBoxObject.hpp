#pragma once

#include "GameObject.hpp"

class StaticBoxObject : public GameObject
{
private:
    BoxRenderer m_BoxRenderer;

public:
    StaticBoxObject();
    StaticBoxObject(const glm::vec3& position, const glm::vec3& size, Shader* shader, Texture* texture, float texScale, float dimm);
    ~StaticBoxObject();

    void Update();

    void SetPos(const glm::vec3& position) override;

};
