#pragma once

#include "../render_objects/BoxRenderer.hpp"
#include "../Directions.hpp"


class GameObject
{
protected:
    glm::vec3 m_Position;
    glm::vec3 m_Size;


public:
    GameObject(const glm::vec3& position, const glm::vec3& size)
        :m_Position(position), m_Size(size)
    {

    }

    virtual ~GameObject()
    {

    }

    inline const glm::vec3& GetPos() const
    {
        return m_Position;
    }

    inline const glm::vec3& GetSize() const
    {
        return m_Size;
    }

    virtual void SetPos(const glm::vec3& position)
    {
        m_Position = position;
    }

};
