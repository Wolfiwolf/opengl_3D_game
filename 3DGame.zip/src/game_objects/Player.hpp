#pragma once

#include "GameObjectCollider.hpp"
#include <map>

class Player : public GameObjectCollider
{

public:
    Player();
    Player(const glm::vec3& position);
    ~Player();

    void Update() override;

    inline bool GetObstacleFront() const
    {
        return m_ObstacleFront;
    }
    inline bool GetObstacleBack() const
    {
        return m_ObstacleBack;
    }
    inline bool GetObstacleLeft() const
    {
        return m_ObstacleLeft;
    }
    inline bool GetObstacleRight() const
    {
        return m_ObstacleRight;
    }

};
