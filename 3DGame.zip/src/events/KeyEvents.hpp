#pragma once

#include "Event.h"

class KeyPressedEvent : public Event
{
public:
	int keyCode;

	KeyPressedEvent(int keyCode)
		:keyCode(keyCode)
	{

	}

	EventType GetEventType() const override
	{
		return KEY_PRESSED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Key " << keyCode << " pressed!";

		return ss.str();
	}

};


class KeyReleasedEvent : public Event
{
public:
	int keyCode;

	KeyReleasedEvent(int keyCode)
		:keyCode(keyCode)
	{

	}

	EventType GetEventType() const override
	{
		return KEY_RELEASED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Key " << keyCode << " released!";

		return ss.str();
	}

};