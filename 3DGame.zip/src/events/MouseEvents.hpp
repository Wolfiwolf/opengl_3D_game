#pragma once

#include "Event.h"




class MouseMovedEvent : public Event
{
public:
	int xPos;
	int yPos;

	MouseMovedEvent(int xPos, int yPos)
		:xPos(xPos), yPos(yPos)
	{

	}

	EventType GetEventType() const override
	{
		return MOUSE_MOVED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Mouse pos => " << xPos << ", " << yPos ;

		return ss.str();
	}

};


class MousePressedEvent : public Event
{
public:
	int button;

	MousePressedEvent(int button)
		:button(button)
	{
		
	}

	EventType GetEventType() const override
	{
		return MOUSE_BUTTON_PRESSED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Mouse button " << ((button == 0) ? "left":"right") << " pressed!";

		return ss.str();
	}

};

class MouseReleasedEvent : public Event
{
public:
	int button;

	MouseReleasedEvent(int button)
		:button(button)
	{

	}

	EventType GetEventType() const override
	{
		return MOUSE_BUTTON_RELEASED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Mouse button " << ((button == 0) ? "left" : "right") << " released!";

		return ss.str();
	}

};