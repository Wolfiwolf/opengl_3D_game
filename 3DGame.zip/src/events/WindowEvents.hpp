#pragma once

#include "Event.h"



class WindowClosedEvent : public Event
{
public:
	WindowClosedEvent()
	{

	}

	EventType GetEventType() const override
	{
		return WINDOW_CLOSED;
	}

	std::string ToString() override
	{
		std::stringstream ss;

		ss << "Window closed!";

		return ss.str();
	}
};