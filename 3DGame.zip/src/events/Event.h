#pragma once
#include <iostream>
#include <string>
#include <sstream>

enum EventType
{
	WINDOW_CLOSED,

	MOUSE_MOVED,
	MOUSE_BUTTON_PRESSED,
	MOUSE_BUTTON_RELEASED,

	KEY_PRESSED,
	KEY_RELEASED
};



class Event
{

public:
	virtual ~Event()
	{

	}

	virtual EventType GetEventType() const = 0;

	virtual std::string ToString() = 0;
};
