clear
if cmake .;
then
	make
fi

